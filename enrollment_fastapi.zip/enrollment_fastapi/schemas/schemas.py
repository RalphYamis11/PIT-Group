from pydantic import BaseModel, EmailStr, field_validator
from typing import Optional
from datetime import datetime


# ─── Auth ─────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    email: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict


# ─── Student ──────────────────────────────────────────────────────
class StudentBase(BaseModel):
    student_id: str
    first_name: str
    middle_name: Optional[str] = ''
    last_name: str
    email: str
    contact_number: Optional[str] = ''
    gender: Optional[str] = ''
    year_level: int = 1
    course: Optional[str] = ''

    @field_validator('year_level')
    @classmethod
    def validate_year_level(cls, v):
        if v not in [1, 2, 3, 4]:
            raise ValueError('Year level must be 1, 2, 3, or 4')
        return v

    @field_validator('student_id')
    @classmethod
    def validate_student_id(cls, v):
        if not v.strip():
            raise ValueError('Student ID cannot be blank')
        return v.strip().upper()

class StudentCreate(StudentBase):
    pass

class StudentUpdate(StudentBase):
    pass

class StudentOut(StudentBase):
    id: int
    full_name: str
    year_level_display: str
    total_enrolled_units: int
    created_at: Optional[datetime]

    model_config = {"from_attributes": True}


# ─── Subject ──────────────────────────────────────────────────────
class SubjectBase(BaseModel):
    subject_code: str
    name: str
    units: int = 3
    subject_type: str = 'lecture'
    description: Optional[str] = ''
    prerequisite_id: Optional[int] = None

    @field_validator('units')
    @classmethod
    def validate_units(cls, v):
        if v < 1 or v > 6:
            raise ValueError('Units must be between 1 and 6')
        return v

    @field_validator('subject_code')
    @classmethod
    def validate_subject_code(cls, v):
        return v.strip().upper()

    @field_validator('subject_type')
    @classmethod
    def validate_subject_type(cls, v):
        allowed = ['lecture', 'lab', 'pe', 'nstp']
        if v not in allowed:
            raise ValueError(f'Subject type must be one of {allowed}')
        return v

class SubjectCreate(SubjectBase):
    pass

class SubjectUpdate(SubjectBase):
    pass

class SubjectPrerequisite(BaseModel):
    id: int
    subject_code: str
    name: str
    model_config = {"from_attributes": True}

class SubjectOut(SubjectBase):
    id: int
    prerequisite_details: Optional[SubjectPrerequisite] = None
    total_sections: int = 0
    created_at: Optional[datetime]
    model_config = {"from_attributes": True}


# ─── Section ──────────────────────────────────────────────────────
class SectionBase(BaseModel):
    section_name: str
    subject: int   # FK id
    max_students: int = 30
    schedule: Optional[str] = ''
    room: Optional[str] = ''
    instructor: Optional[str] = ''

    @field_validator('max_students')
    @classmethod
    def validate_max_students(cls, v):
        if v < 1 or v > 200:
            raise ValueError('Max students must be between 1 and 200')
        return v

class SectionCreate(SectionBase):
    pass

class SectionUpdate(SectionBase):
    pass

class SectionOut(BaseModel):
    id: int
    section_name: str
    subject: int
    subject_details: Optional[SubjectOut] = None
    max_students: int
    schedule: Optional[str]
    room: Optional[str]
    instructor: Optional[str]
    enrolled_count: int
    available_slots: int
    is_full: bool
    created_at: Optional[datetime]
    model_config = {"from_attributes": True}


# ─── Enrollment ───────────────────────────────────────────────────
class EnrollmentBase(BaseModel):
    student: int   # FK id
    section: int   # FK id
    status: str = 'enrolled'
    remarks: Optional[str] = ''

    @field_validator('status')
    @classmethod
    def validate_status(cls, v):
        if v not in ['pending', 'enrolled', 'confirmed', 'rejected', 'dropped']:
            raise ValueError('Status must be pending, enrolled, confirmed, rejected, or dropped')
        return v

class EnrollmentCreate(EnrollmentBase):
    pass

class EnrollmentUpdate(EnrollmentBase):
    pass

class EnrollmentOut(BaseModel):
    id: int
    student: int
    section: int
    student_details: Optional[StudentOut] = None
    section_details: Optional[SectionOut] = None
    status: str
    remarks: Optional[str]
    enrolled_at: Optional[datetime]
    updated_at: Optional[datetime]
    model_config = {"from_attributes": True}


# ─── Dashboard ────────────────────────────────────────────────────
class DashboardOut(BaseModel):
    total_students: int
    total_subjects: int
    total_sections: int
    active_enrollments: int
    dropped_enrollments: int
    full_sections: int
    available_sections: int
    year_breakdown: dict
    subject_type_breakdown: dict


# ─── Summary ──────────────────────────────────────────────────────
class EnrolledSubjectOut(BaseModel):
    enrollment_id: int
    subject_code: str
    subject_name: str
    subject_type: str
    section: str
    units: int
    schedule: Optional[str]
    room: Optional[str]
    instructor: Optional[str]
    enrolled_at: Optional[datetime]

class SummaryOut(BaseModel):
    id: int
    student_id: str
    full_name: str
    email: str
    course: Optional[str]
    year_level: int
    year_level_display: str
    total_enrolled_units: int
    total_subjects: int
    enrolled_subjects: list[EnrolledSubjectOut]
    model_config = {"from_attributes": True}
