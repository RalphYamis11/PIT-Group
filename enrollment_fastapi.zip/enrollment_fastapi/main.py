from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import (
    auth_router,
    students_router,
    subjects_router,
    sections_router,
    enrollments_router,
    dashboard_router,
)

app = FastAPI(
    title="USTP Enrollment System — FastAPI",
    description="Mobile API for the Student Enrollment & Sectioning System. Shares the same PostgreSQL database as the Django web app.",
    version="1.0.0",
)

# ─── CORS ─────────────────────────────────────────────────────────
# Allow React Native (Expo) and any local dev origin
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Routers ──────────────────────────────────────────────────────
app.include_router(auth_router.router)
app.include_router(students_router.router)
app.include_router(subjects_router.router)
app.include_router(sections_router.router)
app.include_router(enrollments_router.router)
app.include_router(dashboard_router.router)


# ─── Root ─────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {
        "message": "USTP Student Enrollment & Sectioning System — FastAPI",
        "version": "1.0.0",
        "docs":    "http://localhost:8001/docs",
        "endpoints": {
            "auth":        "/auth/login, /auth/profile",
            "dashboard":   "/dashboard",
            "students":    "/students",
            "subjects":    "/subjects",
            "sections":    "/sections",
            "enrollments": "/enrollments",
            "summaries":   "/summaries",
        }
    }
