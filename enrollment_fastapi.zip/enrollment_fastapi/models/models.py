from sqlalchemy import (
    Column, Integer, BigInteger, String, Text, Boolean,
    DateTime, ForeignKey, UniqueConstraint
)
from sqlalchemy.orm import relationship
from database import Base


# ─── Django's auth_user table ─────────────────────────────────────
# FastAPI reads this table for login — Django owns/manages it
class User(Base):
    __tablename__ = "user_user"   # Django custom user model table

    id           = Column(BigInteger, primary_key=True, index=True)
    password     = Column(String(128))
    last_login   = Column(DateTime, nullable=True)
    is_superuser = Column(Boolean, default=False)
    email        = Column(String(254), unique=True, index=True)
    first_name   = Column(String(100), default='')
    last_name    = Column(String(100), default='')
    address      = Column(String(255), default='')
    age          = Column(Integer, nullable=True)
    birthday     = Column(DateTime, nullable=True)
    is_active    = Column(Boolean, default=False)
    is_staff     = Column(Boolean, default=False)
    date_joined  = Column(DateTime)
    username     = Column(String(150), unique=True)


# ─── enrollment_student ───────────────────────────────────────────
class Student(Base):
    __tablename__ = "enrollment_student"

    id             = Column(BigInteger, primary_key=True, index=True)
    student_id     = Column(String(20), unique=True, nullable=False)
    first_name     = Column(String(100), nullable=False)
    middle_name    = Column(String(100), default='')
    last_name      = Column(String(100), nullable=False)
    email          = Column(String(254), unique=True, nullable=False)
    contact_number = Column(String(20), default='')
    gender         = Column(String(1), default='')
    year_level     = Column(Integer, default=1)
    course         = Column(String(100), default='')
    created_at     = Column(DateTime)

    enrollments = relationship("Enrollment", back_populates="student")


# ─── enrollment_subject ───────────────────────────────────────────
class Subject(Base):
    __tablename__ = "enrollment_subject"

    id            = Column(BigInteger, primary_key=True, index=True)
    subject_code  = Column(String(20), unique=True, nullable=False)
    name          = Column(String(200), nullable=False)
    units         = Column(Integer, default=3)
    subject_type  = Column(String(20), default='lecture')
    description   = Column(Text, default='')
    prerequisite_id = Column(BigInteger, ForeignKey("enrollment_subject.id"), nullable=True)
    created_at    = Column(DateTime)

    prerequisite  = relationship("Subject", remote_side="Subject.id", foreign_keys=[prerequisite_id])
    sections      = relationship("Section", back_populates="subject")


# ─── enrollment_section ───────────────────────────────────────────
class Section(Base):
    __tablename__ = "enrollment_section"

    id           = Column(BigInteger, primary_key=True, index=True)
    section_name = Column(String(50), nullable=False)
    subject_id   = Column(BigInteger, ForeignKey("enrollment_subject.id"), nullable=False)
    max_students = Column(Integer, default=30)
    schedule     = Column(String(200), default='')
    room         = Column(String(100), default='')
    instructor   = Column(String(200), default='')
    created_at   = Column(DateTime)

    __table_args__ = (UniqueConstraint('section_name', 'subject_id'),)

    subject     = relationship("Subject", back_populates="sections")
    enrollments = relationship("Enrollment", back_populates="section")


# ─── enrollment_enrollment ────────────────────────────────────────
class Enrollment(Base):
    __tablename__ = "enrollment_enrollment"

    id         = Column(BigInteger, primary_key=True, index=True)
    student_id = Column(BigInteger, ForeignKey("enrollment_student.id"), nullable=False)
    section_id = Column(BigInteger, ForeignKey("enrollment_section.id"), nullable=False)
    status     = Column(String(20), default='enrolled')
    remarks    = Column(Text, default='')
    enrolled_at = Column(DateTime)
    updated_at  = Column(DateTime)

    __table_args__ = (UniqueConstraint('student_id', 'section_id'),)

    student = relationship("Student", back_populates="enrollments")
    section = relationship("Section", back_populates="enrollments")
