from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from datetime import datetime, timezone
from typing import Optional
from database import get_db
from models.models import Section, Subject, Enrollment
from schemas.schemas import SectionCreate, SectionUpdate
from auth import get_current_user

router = APIRouter(prefix="/sections", tags=["Sections"])


def get_enrolled_count(section: Section) -> int:
    return sum(1 for e in section.enrollments if e.status == 'enrolled')


def build_section_out(s: Section) -> dict:
    enrolled  = get_enrolled_count(s)
    available = s.max_students - enrolled
    is_full   = enrolled >= s.max_students

    subject_out = None
    if s.subject:
        subject_out = {
            "id":           s.subject.id,
            "subject_code": s.subject.subject_code,
            "name":         s.subject.name,
            "units":        s.subject.units,
            "subject_type": s.subject.subject_type,
            "description":  s.subject.description,
            "prerequisite_id": s.subject.prerequisite_id,
            "prerequisite_details": None,
            "total_sections": len(s.subject.sections),
            "created_at":   s.subject.created_at,
        }

    return {
        "id":              s.id,
        "section_name":    s.section_name,
        "subject":         s.subject_id,
        "subject_details": subject_out,
        "max_students":    s.max_students,
        "schedule":        s.schedule,
        "room":            s.room,
        "instructor":      s.instructor,
        "enrolled_count":  enrolled,
        "available_slots": available,
        "is_full":         is_full,
        "created_at":      s.created_at,
    }


@router.get("/")
def list_sections(
    subject:    Optional[int] = Query(None),
    instructor: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    q = db.query(Section).order_by(Section.section_name)
    if subject:
        q = q.filter(Section.subject_id == subject)
    if instructor:
        q = q.filter(Section.instructor.icontains(instructor))
    return [build_section_out(s) for s in q.all()]


@router.get("/{section_id}")
def get_section(
    section_id: int,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    s = db.query(Section).filter(Section.id == section_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Section not found.")
    return build_section_out(s)


@router.post("/", status_code=status.HTTP_201_CREATED)
def create_section(
    payload: SectionCreate,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    subject = db.query(Subject).filter(Subject.id == payload.subject).first()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found.")

    existing = db.query(Section).filter(
        Section.section_name == payload.section_name,
        Section.subject_id   == payload.subject
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Section name already exists for this subject.")

    section = Section(
        section_name = payload.section_name,
        subject_id   = payload.subject,
        max_students = payload.max_students,
        schedule     = payload.schedule,
        room         = payload.room,
        instructor   = payload.instructor,
        created_at   = datetime.now(timezone.utc),
    )
    db.add(section)
    db.commit()
    db.refresh(section)
    return build_section_out(section)


@router.put("/{section_id}")
def update_section(
    section_id: int,
    payload: SectionUpdate,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    s = db.query(Section).filter(Section.id == section_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Section not found.")

    s.section_name = payload.section_name
    s.subject_id   = payload.subject
    s.max_students = payload.max_students
    s.schedule     = payload.schedule
    s.room         = payload.room
    s.instructor   = payload.instructor
    db.commit()
    db.refresh(s)
    return build_section_out(s)


@router.delete("/{section_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_section(
    section_id: int,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    s = db.query(Section).filter(Section.id == section_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Section not found.")
    db.delete(s)
    db.commit()
