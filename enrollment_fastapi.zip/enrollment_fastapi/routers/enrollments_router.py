from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import or_
from datetime import datetime, timezone
from typing import Optional
from database import get_db
from models.models import Enrollment, Student, Section
from schemas.schemas import EnrollmentCreate, EnrollmentUpdate
from auth import get_current_user
from routers.students_router import build_student_out
from routers.sections_router import build_section_out

router = APIRouter(prefix="/enrollments", tags=["Enrollments"])


def build_enrollment_out(e: Enrollment, db: Session) -> dict:
    return {
        "id":              e.id,
        "student":         e.student_id,
        "section":         e.section_id,
        "student_details": build_student_out(e.student, db) if e.student else None,
        "section_details": build_section_out(e.section)     if e.section else None,
        "status":          e.status,
        "remarks":         e.remarks,
        "enrolled_at":     e.enrolled_at,
        "updated_at":      e.updated_at,
    }


@router.get("/")
def list_enrollments(
    student:    Optional[int] = Query(None),
    section:    Optional[int] = Query(None),
    status_filter: Optional[str] = Query(None, alias="status"),
    subject:    Optional[int] = Query(None),
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    q = db.query(Enrollment).order_by(Enrollment.enrolled_at.desc())
    if student:
        q = q.filter(Enrollment.student_id == student)
    if section:
        q = q.filter(Enrollment.section_id == section)
    if status_filter:
        q = q.filter(Enrollment.status == status_filter)
    if subject:
        q = q.join(Section).filter(Section.subject_id == subject)
    return [build_enrollment_out(e, db) for e in q.all()]


@router.get("/{enrollment_id}")
def get_enrollment(
    enrollment_id: int,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    e = db.query(Enrollment).filter(Enrollment.id == enrollment_id).first()
    if not e:
        raise HTTPException(status_code=404, detail="Enrollment not found.")
    return build_enrollment_out(e, db)


@router.post("/", status_code=status.HTTP_201_CREATED)
def create_enrollment(
    payload: EnrollmentCreate,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    student = db.query(Student).filter(Student.id == payload.student).first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found.")

    section = db.query(Section).filter(Section.id == payload.section).first()
    if not section:
        raise HTTPException(status_code=404, detail="Section not found.")

    # Check already enrolled/pending in this exact section
    existing = db.query(Enrollment).filter(
        Enrollment.student_id == payload.student,
        Enrollment.section_id == payload.section,
        Enrollment.status.in_(['pending', 'enrolled', 'confirmed'])
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Student already has an active enrollment in this section.")

    # Check already enrolled in another section of the same subject
    same_subject = db.query(Enrollment).join(Section).filter(
        Enrollment.student_id == payload.student,
        Section.subject_id    == section.subject_id,
        Enrollment.status.in_(['pending', 'enrolled', 'confirmed'])
    ).first()
    if same_subject:
        raise HTTPException(
            status_code=400,
            detail=f"Student is already enrolled in another section of {section.subject.subject_code}."
        )

    # Check section capacity
    enrolled_count = sum(1 for e in section.enrollments if e.status in ['enrolled', 'confirmed'])
    if enrolled_count >= section.max_students:
        raise HTTPException(
            status_code=400,
            detail=f"Section {section.section_name} is already full ({section.max_students}/{section.max_students})."
        )

    now = datetime.now(timezone.utc)
    enrollment = Enrollment(
        student_id  = payload.student,
        section_id  = payload.section,
        status      = 'pending',   # ← always starts as pending, admin confirms
        remarks     = payload.remarks,
        enrolled_at = now,
        updated_at  = now,
    )
    db.add(enrollment)
    db.commit()
    db.refresh(enrollment)
    return {
        "message":    "Enrollment submitted. Waiting for admin approval.",
        "enrollment": build_enrollment_out(enrollment, db)
    }


@router.post("/{enrollment_id}/confirm")
def confirm_enrollment(
    enrollment_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    if not (current_user.is_staff or current_user.is_superuser):
        raise HTTPException(status_code=403, detail="Admin access required.")

    e = db.query(Enrollment).filter(Enrollment.id == enrollment_id).first()
    if not e:
        raise HTTPException(status_code=404, detail="Enrollment not found.")
    if e.status != 'pending':
        raise HTTPException(status_code=400, detail=f"Cannot confirm — status is '{e.status}'.")

    e.status     = 'enrolled'
    e.updated_at = datetime.now(timezone.utc)
    db.commit()
    return {"message": "Enrollment confirmed successfully.", "enrollment": build_enrollment_out(e, db)}


@router.post("/{enrollment_id}/reject")
def reject_enrollment(
    enrollment_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    if not (current_user.is_staff or current_user.is_superuser):
        raise HTTPException(status_code=403, detail="Admin access required.")

    e = db.query(Enrollment).filter(Enrollment.id == enrollment_id).first()
    if not e:
        raise HTTPException(status_code=404, detail="Enrollment not found.")
    if e.status != 'pending':
        raise HTTPException(status_code=400, detail=f"Cannot reject — status is '{e.status}'.")

    e.status     = 'rejected'
    e.updated_at = datetime.now(timezone.utc)
    db.commit()
    return {"message": "Enrollment rejected.", "enrollment": build_enrollment_out(e, db)}


@router.put("/{enrollment_id}")
def update_enrollment(
    enrollment_id: int,
    payload: EnrollmentUpdate,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    e = db.query(Enrollment).filter(Enrollment.id == enrollment_id).first()
    if not e:
        raise HTTPException(status_code=404, detail="Enrollment not found.")

    e.student_id = payload.student
    e.section_id = payload.section
    e.status     = payload.status
    e.remarks    = payload.remarks
    e.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(e)
    return {"message": "Enrollment updated.", "enrollment": build_enrollment_out(e, db)}


@router.delete("/{enrollment_id}")
def drop_enrollment(
    enrollment_id: int,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    # Matches Django's destroy() — sets status='dropped', does NOT hard delete
    e = db.query(Enrollment).filter(Enrollment.id == enrollment_id).first()
    if not e:
        raise HTTPException(status_code=404, detail="Enrollment not found.")

    student_name = f"{e.student.first_name} {e.student.last_name}" if e.student else "Student"
    e.status     = 'dropped'
    e.updated_at = datetime.now(timezone.utc)
    db.commit()
    return {"message": f"Enrollment dropped for {student_name}."}
