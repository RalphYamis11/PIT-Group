from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional
from database import get_db
from models.models import Student, Subject, Section, Enrollment
from auth import get_current_user
from routers.students_router import build_student_out, YEAR_DISPLAY

router = APIRouter(tags=["Dashboard & Summaries"])


# ─── Dashboard ────────────────────────────────────────────────────
@router.get("/dashboard")
def dashboard_stats(
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    total_students = db.query(Student).count()
    total_subjects = db.query(Subject).count()
    total_sections = db.query(Section).count()
    active_enroll  = db.query(Enrollment).filter(Enrollment.status == 'enrolled').count()
    dropped_enroll = db.query(Enrollment).filter(Enrollment.status == 'dropped').count()

    all_sections   = db.query(Section).all()
    full_sections  = sum(
        1 for s in all_sections
        if sum(1 for e in s.enrollments if e.status == 'enrolled') >= s.max_students
    )
    available_sections = total_sections - full_sections

    year_breakdown = {
        f'year_{i}': db.query(Student).filter(Student.year_level == i).count()
        for i in range(1, 5)
    }

    type_breakdown = {
        t: db.query(Subject).filter(Subject.subject_type == t).count()
        for t in ['lecture', 'lab', 'pe', 'nstp']
    }

    return {
        "total_students":         total_students,
        "total_subjects":         total_subjects,
        "total_sections":         total_sections,
        "active_enrollments":     active_enroll,
        "dropped_enrollments":    dropped_enroll,
        "full_sections":          full_sections,
        "available_sections":     available_sections,
        "year_breakdown":         year_breakdown,
        "subject_type_breakdown": type_breakdown,
    }


# ─── Summaries ────────────────────────────────────────────────────
@router.get("/summaries")
def list_summaries(
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    from sqlalchemy import or_
    q = db.query(Student).order_by(Student.student_id)
    if search:
        q = q.filter(or_(
            Student.first_name.icontains(search),
            Student.last_name.icontains(search),
            Student.student_id.icontains(search),
        ))
    return [build_summary_out(s) for s in q.all()]


@router.get("/summaries/{student_id}")
def get_student_summary(
    student_id: int,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    s = db.query(Student).filter(Student.id == student_id).first()
    if not s:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Student not found.")
    return build_summary_out(s)


def build_summary_out(s: Student) -> dict:
    active_enrollments = [e for e in s.enrollments if e.status == 'enrolled']
    total_units = sum(e.section.subject.units for e in active_enrollments)
    middle = s.middle_name or ''
    full_name = (
        f"{s.first_name} {middle[0]}. {s.last_name}"
        if middle else f"{s.first_name} {s.last_name}"
    )

    enrolled_subjects = [
        {
            "enrollment_id": e.id,
            "subject_code":  e.section.subject.subject_code,
            "subject_name":  e.section.subject.name,
            "subject_type":  e.section.subject.subject_type,
            "section":       e.section.section_name,
            "units":         e.section.subject.units,
            "schedule":      e.section.schedule,
            "room":          e.section.room,
            "instructor":    e.section.instructor,
            "enrolled_at":   e.enrolled_at,
        }
        for e in active_enrollments
    ]

    return {
        "id":                   s.id,
        "student_id":           s.student_id,
        "full_name":            full_name,
        "email":                s.email,
        "course":               s.course,
        "year_level":           s.year_level,
        "year_level_display":   YEAR_DISPLAY.get(s.year_level, 'Unknown'),
        "total_enrolled_units": total_units,
        "total_subjects":       len(active_enrollments),
        "enrolled_subjects":    enrolled_subjects,
    }
