from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from database import get_db
from models.models import User
from schemas.schemas import LoginRequest, TokenResponse
from auth import verify_password, create_access_token, get_current_user
from datetime import datetime, timezone
import hashlib, base64, os, secrets, smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv

load_dotenv()

FRONTEND_URL        = os.getenv("FRONTEND_URL", "http://localhost:3000")
EMAIL_HOST          = os.getenv("EMAIL_HOST", "smtp.gmail.com")
EMAIL_PORT          = int(os.getenv("EMAIL_PORT", 587))
EMAIL_HOST_USER     = os.getenv("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = os.getenv("EMAIL_HOST_PASSWORD", "")
DEFAULT_FROM_EMAIL  = os.getenv("DEFAULT_FROM_EMAIL", "EnrollPro <noreply@ustp.edu.ph>")

router = APIRouter(prefix="/auth", tags=["Auth"])


# ─── Schemas ──────────────────────────────────────────────────────
class RegisterRequest(BaseModel):
    email: str
    password: str
    first_name: str
    last_name: str
    address: Optional[str] = ''
    age: Optional[int] = None

class ActivateRequest(BaseModel):
    uid: str
    token: str


# ─── Helpers ──────────────────────────────────────────────────────
def make_django_password(plain: str) -> str:
    """Create Django-compatible pbkdf2_sha256 password hash."""
    iterations = 1200000
    salt = secrets.token_urlsafe(12)[:22]
    dk = hashlib.pbkdf2_hmac('sha256', plain.encode(), salt.encode(), iterations, dklen=32)
    hash_b64 = base64.b64encode(dk).decode('ascii')
    return f"pbkdf2_sha256${iterations}${salt}${hash_b64}"


def make_activation_token(user_id: int) -> str:
    """Simple activation token."""
    secret = os.getenv("ACTIVATION_SECRET", "activation-secret")
    raw = f"{user_id}-{secret}"
    return hashlib.sha256(raw.encode()).hexdigest()[:40]


def send_activation_email(email: str, uid: str, token: str, first_name: str):
    """Send activation email via SMTP or print to console."""
    activation_url = f"{FRONTEND_URL}/activate/{uid}/{token}"

    # Always print to console (useful for development)
    print(f"\n{'='*60}")
    print(f"ACTIVATION EMAIL for {email}")
    print(f"URL: {activation_url}")
    print(f"{'='*60}\n")

    # Try sending real email if configured
    if EMAIL_HOST_USER and EMAIL_HOST_PASSWORD:
        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = "Activate your EnrollPro account"
            msg["From"]    = DEFAULT_FROM_EMAIL
            msg["To"]      = email

            text = f"Hi {first_name},\n\nActivate your account:\n{activation_url}\n\nThanks,\nUSTP EnrollPro"
            html = f"""
            <p>Hi <b>{first_name}</b>,</p>
            <p>Please activate your EnrollPro account by clicking the link below:</p>
            <p><a href="{activation_url}">{activation_url}</a></p>
            <p>Thanks,<br>USTP EnrollPro Team</p>
            """
            msg.attach(MIMEText(text, "plain"))
            msg.attach(MIMEText(html, "html"))

            with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
                server.starttls()
                server.login(EMAIL_HOST_USER, EMAIL_HOST_PASSWORD)
                server.sendmail(EMAIL_HOST_USER, email, msg.as_string())
            print(f"✅ Email sent to {email}")
        except Exception as e:
            print(f"⚠️ Email send failed: {e} — check activation URL above")


# ─── Login ────────────────────────────────────────────────────────
@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(
        User.email.ilike(payload.email.strip())
    ).first()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="No account found with this email."
        )

    if not verify_password(payload.password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect password."
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Account not activated. Please check your email."
        )

    token = create_access_token({"sub": str(user.id)})

    return {
        "access_token": token,
        "token_type":   "bearer",
        "user": {
            "id":           user.id,
            "email":        user.email,
            "first_name":   user.first_name,
            "last_name":    user.last_name,
            "full_name":    f"{user.first_name} {user.last_name}".strip() or user.email,
            "is_staff":     user.is_staff,
            "is_superuser": user.is_superuser,
        }
    }


# ─── Register ─────────────────────────────────────────────────────
@router.post("/register", status_code=status.HTTP_201_CREATED)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    # Check if email already exists
    existing = db.query(User).filter(
        User.email.ilike(payload.email.strip())
    ).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email already exists."
        )

    # Create user with Django-compatible password hash
    now = datetime.now(timezone.utc)
    user = User(
        email       = payload.email.strip().lower(),
        password    = make_django_password(payload.password),
        first_name  = payload.first_name.strip(),
        last_name   = payload.last_name.strip(),
        address     = payload.address or '',
        age         = payload.age,
        is_active   = False,   # requires activation
        is_staff    = False,
        is_superuser= False,
        date_joined = now,
        last_login  = None,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    # Generate and send activation
    uid   = str(user.id)
    token = make_activation_token(user.id)
    send_activation_email(user.email, uid, token, user.first_name)

    return {
        "message": "Account created! Please check your email to activate your account.",
        "email":   user.email,
    }


# ─── Activate ─────────────────────────────────────────────────────
@router.post("/activate")
def activate(payload: ActivateRequest, db: Session = Depends(get_db)):
    try:
        user_id = int(payload.uid)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid activation link.")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")

    if user.is_active:
        return {"message": "Account is already activated. You can log in."}

    expected_token = make_activation_token(user.id)
    if payload.token != expected_token:
        raise HTTPException(status_code=400, detail="Invalid or expired activation token.")

    user.is_active = True
    db.commit()

    return {"message": "Account activated successfully! You can now log in."}


# ─── Profile ──────────────────────────────────────────────────────
@router.get("/profile")
def profile(current_user: User = Depends(get_current_user)):
    return {
        "id":           current_user.id,
        "email":        current_user.email,
        "first_name":   current_user.first_name,
        "last_name":    current_user.last_name,
        "full_name":    f"{current_user.first_name} {current_user.last_name}".strip(),
        "is_staff":     current_user.is_staff,
        "is_superuser": current_user.is_superuser,
    }
