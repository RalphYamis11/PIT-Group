from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import or_
from datetime import datetime, timezone
from typing import Optional
from database import get_db
from models.models import Subject
from schemas.schemas import SubjectCreate, SubjectUpdate
from auth import get_current_user

router = APIRouter(prefix="/subjects", tags=["Subjects"])


def build_subject_out(s: Subject) -> dict:
    prereq = None
    if s.prerequisite:
        prereq = {
            "id":           s.prerequisite.id,
            "subject_code": s.prerequisite.subject_code,
            "name":         s.prerequisite.name,
        }
    return {
        "id":                   s.id,
        "subject_code":         s.subject_code,
        "name":                 s.name,
        "units":                s.units,
        "subject_type":         s.subject_type,
        "description":          s.description,
        "prerequisite_id":      s.prerequisite_id,
        "prerequisite_details": prereq,
        "total_sections":       len(s.sections),
        "created_at":           s.created_at,
    }


@router.get("/")
def list_subjects(
    search:       Optional[str] = Query(None),
    type:         Optional[str] = Query(None),
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    q = db.query(Subject).order_by(Subject.subject_code)
    if search:
        q = q.filter(or_(
            Subject.subject_code.icontains(search),
            Subject.name.icontains(search),
        ))
    if type:
        q = q.filter(Subject.subject_type == type)
    return [build_subject_out(s) for s in q.all()]


@router.get("/{subject_id}")
def get_subject(
    subject_id: int,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    s = db.query(Subject).filter(Subject.id == subject_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Subject not found.")
    return build_subject_out(s)


@router.post("/", status_code=status.HTTP_201_CREATED)
def create_subject(
    payload: SubjectCreate,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    if db.query(Subject).filter(Subject.subject_code == payload.subject_code.upper()).first():
        raise HTTPException(status_code=400, detail="Subject code already exists.")

    subject = Subject(
        **payload.model_dump(),
        created_at=datetime.now(timezone.utc)
    )
    db.add(subject)
    db.commit()
    db.refresh(subject)
    return build_subject_out(subject)


@router.put("/{subject_id}")
def update_subject(
    subject_id: int,
    payload: SubjectUpdate,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    s = db.query(Subject).filter(Subject.id == subject_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Subject not found.")
    for k, v in payload.model_dump().items():
        setattr(s, k, v)
    db.commit()
    db.refresh(s)
    return build_subject_out(s)


@router.delete("/{subject_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_subject(
    subject_id: int,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    s = db.query(Subject).filter(Subject.id == subject_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Subject not found.")
    db.delete(s)
    db.commit()
