from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import or_
from datetime import datetime, timezone
from typing import Optional
from database import get_db
from models.models import Student, Enrollment
from schemas.schemas import StudentCreate, StudentUpdate, StudentOut
from auth import get_current_user

router = APIRouter(prefix="/students", tags=["Students"])

YEAR_DISPLAY = {1: '1st Year', 2: '2nd Year', 3: '3rd Year', 4: '4th Year'}
GENDER_DISPLAY = {'M': 'Male', 'F': 'Female', 'O': 'Other'}


def build_student_out(s: Student, db: Session) -> dict:
    enrolled_units = sum(
        e.section.subject.units
        for e in s.enrollments
        if e.status == 'enrolled'
    )
    middle = s.middle_name or ''
    full_name = (
        f"{s.first_name} {middle[0]}. {s.last_name}"
        if middle else f"{s.first_name} {s.last_name}"
    )
    return {
        "id":                   s.id,
        "student_id":           s.student_id,
        "first_name":           s.first_name,
        "middle_name":          s.middle_name,
        "last_name":            s.last_name,
        "full_name":            full_name,
        "email":                s.email,
        "contact_number":       s.contact_number,
        "gender":               s.gender,
        "year_level":           s.year_level,
        "year_level_display":   YEAR_DISPLAY.get(s.year_level, 'Unknown'),
        "course":               s.course,
        "total_enrolled_units": enrolled_units,
        "created_at":           s.created_at,
    }


@router.get("/")
def list_students(
    search:     Optional[str] = Query(None),
    year_level: Optional[int] = Query(None),
    course:     Optional[str] = Query(None),
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    q = db.query(Student).order_by(Student.student_id)
    if search:
        q = q.filter(or_(
            Student.first_name.icontains(search),
            Student.last_name.icontains(search),
            Student.student_id.icontains(search),
            Student.email.icontains(search),
        ))
    if year_level:
        q = q.filter(Student.year_level == year_level)
    if course:
        q = q.filter(Student.course.icontains(course))
    students = q.all()
    return [build_student_out(s, db) for s in students]


@router.get("/{student_id}")
def get_student(
    student_id: int,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    s = db.query(Student).filter(Student.id == student_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Student not found.")
    return build_student_out(s, db)


@router.post("/", status_code=status.HTTP_201_CREATED)
def create_student(
    payload: StudentCreate,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    if db.query(Student).filter(Student.student_id == payload.student_id.upper()).first():
        raise HTTPException(status_code=400, detail="Student ID already exists.")
    if db.query(Student).filter(Student.email == payload.email.lower()).first():
        raise HTTPException(status_code=400, detail="Email already exists.")

    student = Student(
        **payload.model_dump(),
        created_at=datetime.now(timezone.utc)
    )
    db.add(student)
    db.commit()
    db.refresh(student)
    return build_student_out(student, db)


@router.put("/{student_id}")
def update_student(
    student_id: int,
    payload: StudentUpdate,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    s = db.query(Student).filter(Student.id == student_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Student not found.")

    for k, v in payload.model_dump().items():
        setattr(s, k, v)
    db.commit()
    db.refresh(s)
    return build_student_out(s, db)


@router.delete("/{student_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_student(
    student_id: int,
    db: Session = Depends(get_db),
    _=Depends(get_current_user)
):
    s = db.query(Student).filter(Student.id == student_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Student not found.")
    db.delete(s)
    db.commit()
