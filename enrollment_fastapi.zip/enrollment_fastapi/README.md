# USTP Enrollment System — FastAPI Backend (Mobile)

Runs on **port 8001** alongside Django (port 8000).
Both share the same `enrollment_db` PostgreSQL database.

---

## 📁 Structure

```
enrollment_fastapi/
├── main.py               ← FastAPI app entry point
├── database.py           ← PostgreSQL connection (SQLAlchemy)
├── auth.py               ← JWT auth, reads Django's password hash
├── .env                  ← DB credentials + JWT secret
├── requirements.txt
├── models/
│   └── models.py         ← Mirrors Django's exact table names
├── schemas/
│   └── schemas.py        ← Pydantic request/response models
└── routers/
    ├── auth_router.py        ← POST /auth/login, GET /auth/profile
    ├── students_router.py    ← /students CRUD
    ├── subjects_router.py    ← /subjects CRUD
    ├── sections_router.py    ← /sections CRUD
    ├── enrollments_router.py ← /enrollments CRUD
    └── dashboard_router.py   ← /dashboard + /summaries
```

---

## 🚀 Setup

### 1. Create virtual environment
```bash
cd enrollment_fastapi
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure .env
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=enrollment_db
DB_USER=postgres
DB_PASSWORD=yourpassword     ← same password as Django settings.py

SECRET_KEY=any-long-random-string-here
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60
```

### 4. Run FastAPI
```bash
# Note: port 8001 so it doesn't clash with Django on 8000
uvicorn main:app --reload --port 8001
```

### 5. Test it
Open browser: **http://localhost:8001/docs**
You'll see the full interactive Swagger UI — test all endpoints there!

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | `/auth/login` | Login with email + password → returns JWT |
| GET | `/auth/profile` | Current user info |
| GET | `/dashboard` | Stats: totals, year breakdown, type breakdown |
| GET | `/students` | List students (search, year_level, course filters) |
| POST | `/students` | Create student |
| GET | `/students/{id}` | Get one student |
| PUT | `/students/{id}` | Update student |
| DELETE | `/students/{id}` | Delete student |
| GET | `/subjects` | List subjects (search, type filter) |
| POST | `/subjects` | Create subject |
| GET | `/subjects/{id}` | Get one subject |
| PUT | `/subjects/{id}` | Update subject |
| DELETE | `/subjects/{id}` | Delete subject |
| GET | `/sections` | List sections (subject, instructor filters) |
| POST | `/sections` | Create section |
| GET | `/sections/{id}` | Get one section |
| PUT | `/sections/{id}` | Update section |
| DELETE | `/sections/{id}` | Delete section |
| GET | `/enrollments` | List enrollments (student, section, status, subject filters) |
| POST | `/enrollments` | Enroll student |
| GET | `/enrollments/{id}` | Get one enrollment |
| PUT | `/enrollments/{id}` | Update enrollment |
| DELETE | `/enrollments/{id}` | Drop enrollment (sets status='dropped') |
| GET | `/summaries` | All students + their enrolled subjects |
| GET | `/summaries/{id}` | One student's full enrollment summary |

---

## ⚠️ Important Notes

**Table names** — FastAPI reads Django's exact tables:
- `user_user` (your custom User model)
- `enrollment_student`
- `enrollment_subject`
- `enrollment_section`
- `enrollment_enrollment`

**Password verification** — FastAPI uses `passlib` which understands
Django's PBKDF2 password hash format automatically. No changes needed.

**JWT** — FastAPI uses its own JWT (separate from Django's JWT).
The mobile app stores FastAPI's token in AsyncStorage.

**Delete enrollment** — Like Django, DELETE sets `status='dropped'`
and returns HTTP 200, not a hard delete.

**Both servers running simultaneously:**
```
Django  → http://localhost:8000  (web app)
FastAPI → http://localhost:8001  (mobile app)
```
