# EnrollPro — React Native (Expo) Mobile App
### USTP Student Enrollment & Sectioning System

---

## 🔑 REQUIRED: Add Token Auth to Django (3 steps)

Your Django backend uses **session auth** which doesn't work well on mobile.
Add **Token Auth** alongside it — your web app stays unaffected.

### Step 1 — settings.py
```python
INSTALLED_APPS = [
    ...
    'rest_framework.authtoken',   # ← add this
]

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.TokenAuthentication',  # ← mobile
        'rest_framework.authentication.SessionAuthentication',  # ← web (keep)
    ],
}
```

### Step 2 — Run migration
```bash
python manage.py migrate
```

### Step 3 — Update auth_views.py login_view
Find `return Response({...})` in your `login_view` and add the token:

```python
from rest_framework.authtoken.models import Token

# Inside login_view, after authentication succeeds:
token, _ = Token.objects.get_or_create(user=user)

return Response({
    'message': 'Login successful.',
    'token': token.key,            # ← add this line
    'user': {
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'first_name': user.first_name,
        'last_name': user.last_name,
        'full_name': f"{user.first_name} {user.last_name}".strip() or user.username,
        'is_staff': user.is_staff,
        'is_superuser': user.is_superuser,
    }
})
```

That's it. The mobile app automatically stores and uses this token.

---

## 🚀 Mobile App Setup

```bash
cd EnrollmentApp
npm install
npx expo start
```

Press `a` for Android emulator, `i` for iOS, or scan QR with Expo Go.

### Update BASE_URL in `src/services/api.js`
```js
// Android emulator (can reach your PC's localhost):
export const BASE_URL = 'http://10.0.2.2:8000/api';

// Real device on same WiFi:
export const BASE_URL = 'http://192.168.x.x:8000/api';  // your PC's local IP

// iOS simulator / browser:
export const BASE_URL = 'http://localhost:8000/api';
```

---

## 📁 Project Structure

```
EnrollmentApp/
├── App.js
├── app.json
├── package.json
├── babel.config.js
└── src/
    ├── services/
    │   └── api.js            ← All API calls, exact endpoint match
    ├── context/
    │   └── AuthContext.js    ← email-based auth, token storage
    ├── navigation/
    │   └── AppNavigator.js   ← Bottom tabs + stack
    ├── screens/
    │   ├── LoginScreen.js       ← Email + Password (matches login_view)
    │   ├── DashboardScreen.js   ← /api/dashboard/ stats
    │   ├── StudentsScreen.js    ← /api/students/ CRUD
    │   ├── SubjectsScreen.js    ← /api/subjects/ CRUD
    │   ├── SectionsScreen.js    ← /api/sections/ CRUD
    │   └── EnrollmentsScreen.js ← /api/enrollments/ CRUD
    ├── components/
    │   └── UI.js             ← Shared components
    └── theme.js              ← Colors, shadows, radii
```

---

## 🔌 Exact API Mapping

### Auth
| Endpoint | Method | Mobile uses |
|---|---|---|
| `/api/auth/login/` | POST | `{email, password}` — NOT username |
| `/api/auth/logout/` | POST | clears session |
| `/api/auth/profile/` | GET | current user info |

### Dashboard (`/api/dashboard/`)
Response fields used by mobile:
- `total_students`, `total_subjects`, `total_sections`
- `active_enrollments`, `dropped_enrollments`
- `full_sections`, `available_sections`
- `year_breakdown`: `{ year_1, year_2, year_3, year_4 }`
- `subject_type_breakdown`: `{ lecture, lab, pe, nstp }`

### Students (`/api/students/`)
Model fields: `student_id`, `first_name`, `middle_name`, `last_name`, `full_name`,
`email`, `contact_number`, `gender`, `year_level` (1–4), `course`,
`total_enrolled_units`, `created_at`
Search: `?search=` | Filter: `?year_level=` `?course=`

### Subjects (`/api/subjects/`)
Model fields: `subject_code`, **`name`** (not subject_name!), `units` (1–6),
`subject_type` (`lecture`/`lab`/`pe`/`nstp`),
`description`, `prerequisite` (FK id), `prerequisite_details`, `total_sections`
Search: `?search=` | Filter: `?type=`

### Sections (`/api/sections/`)
Model fields: `section_name`, `subject` (FK id), `subject_details` (nested),
`max_students`, `schedule`, `room`, `instructor`,
`enrolled_count`, `available_slots`, `is_full`, `created_at`
Filter: `?subject=<id>` `?instructor=`

### Enrollments (`/api/enrollments/`)
Model fields: `student` (FK id), `section` (FK id),
`student_details` (nested), `section_details` (nested, includes `subject_details`),
`status` (**lowercase**: `enrolled` / `dropped`), `remarks`, `enrolled_at`, `updated_at`
**Important:** DELETE does NOT remove record — sets `status='dropped'`, returns HTTP 200
Filter: `?student=` `?section=` `?status=` `?subject=`

### Summaries (`/api/summaries/`)
Per-student view with all enrolled subjects, schedule, room, instructor.

---

## ✅ Features

- 🔐 Email + Password login with Token auth (persists sessions)
- 🏠 Dashboard: 6 stat cards + year breakdown bars + subject type grid
- 👨‍🎓 Students: search, filter by year/course, add/edit/delete
  - Fields: student_id, first/middle/last name, email, contact, gender, year level, course
- 📚 Subjects: search, filter by type (lecture/lab/pe/nstp), CRUD with prerequisite
- 🏫 Sections: CRUD with subject picker, live capacity progress bar
- 📋 Enrollments: CRUD with searchable student/section pickers
  - Section picker shows available slots + blocks full sections
  - Drop = DELETE endpoint (sets status='dropped', not hard delete)
  - Filter by status (enrolled / dropped)

---

## ⚠️ Common Issues

| Problem | Fix |
|---|---|
| Network error on Android emulator | Use `10.0.2.2` not `localhost` |
| Login fails with 401 | Check email is lowercase, user exists in Django |
| `auth_token not found` warning | Add Token auth to Django (see above) |
| Section picker shows wrong data | Ensure `/api/sections/` returns `subject_details` nested |
| Drop returns 404/500 | Check `EnrollmentDetailView.destroy()` sets `status='dropped'` |
| CORS error | Add `django-cors-headers`, set `CORS_ALLOW_CREDENTIALS = True` |
