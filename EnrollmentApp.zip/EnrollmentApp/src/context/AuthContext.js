import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { login as apiLogin, logout as apiLogout } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]   = useState(null);
  const [loading, setLoading] = useState(true);

  // Restore session on app launch
  useEffect(() => {
    (async () => {
      try {
        const stored = await AsyncStorage.getItem('auth_user');
        if (stored) setUser(JSON.parse(stored));
      } catch (_) {}
      setLoading(false);
    })();
  }, []);

  const login = async (email, password) => {
    const res = await apiLogin(email.trim().toLowerCase(), password);
    const { user: u, token } = res.data;

    // Store token if Django returns one (after adding Token auth — see README)
    if (token) {
      await AsyncStorage.setItem('auth_token', token);
    }
    await AsyncStorage.setItem('auth_user', JSON.stringify(u));
    setUser(u);
    return res.data;
  };

  const logout = async () => {
    try { await apiLogout(); } catch (_) {}
    await AsyncStorage.multiRemove(['auth_token', 'auth_user']);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
