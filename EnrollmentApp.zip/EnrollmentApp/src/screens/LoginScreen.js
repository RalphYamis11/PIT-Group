import React, { useState } from 'react';
import {
  View, Text, StyleSheet, KeyboardAvoidingView,
  Platform, ScrollView, Alert, TouchableOpacity, StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { AppInput, AppButton } from '../components/UI';
import { COLORS, FONT, RADIUS, SHADOW } from '../theme';

export default function LoginScreen({ navigation }) {
  const { login } = useAuth();
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [errors, setErrors]     = useState({});

  const validate = () => {
    const e = {};
    if (!email.trim()) e.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(email)) e.email = 'Enter a valid email';
    if (!password) e.password = 'Password is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleLogin = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      await login(email, password);
    } catch (err) {
      const data = err.response?.data;
      const msg  = data?.detail || data?.error || 'Invalid credentials.';
      Alert.alert('Sign In Failed', msg);
    } finally { setLoading(false); }
  };

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.navy} />
      <View style={styles.root}>
        {/* Top section */}
        <LinearGradient
          colors={[COLORS.navy, COLORS.navyMid, '#1E3A8A']}
          style={styles.topSection}
        >
          {/* Logo */}
          <View style={styles.logoWrap}>
            <View style={styles.logoOuter}>
              <View style={styles.logoInner}>
                <Ionicons name="school" size={32} color={COLORS.gold} />
              </View>
            </View>
            <Text style={styles.appName}>EnrollPro</Text>
            <Text style={styles.appTagline}>USTP Enrollment & Sectioning System</Text>
          </View>

          {/* Decorative dots */}
          <View style={styles.dot1} />
          <View style={styles.dot2} />
        </LinearGradient>

        {/* Bottom card */}
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <ScrollView
            contentContainerStyle={styles.scroll}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Welcome back</Text>
              <Text style={styles.cardSub}>Sign in to your account</Text>

              <AppInput
                label="Email Address"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
                returnKeyType="next"
                error={errors.email}
                placeholder="you@ustp.edu.ph"
                icon="mail-outline"
              />

              <AppInput
                label="Password"
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPass}
                returnKeyType="done"
                onSubmitEditing={handleLogin}
                error={errors.password}
                placeholder="Enter your password"
                icon="lock-closed-outline"
                rightIcon={showPass ? 'eye-off-outline' : 'eye-outline'}
                onRightIconPress={() => setShowPass(!showPass)}
              />

              <AppButton
                title="Sign In"
                onPress={handleLogin}
                loading={loading}
                variant="gold"
                icon="log-in-outline"
                style={styles.loginBtn}
              />

              <View style={styles.divider}>
                <View style={styles.dividerLine} />
                <Text style={styles.dividerText}>or</Text>
                <View style={styles.dividerLine} />
              </View>

              <TouchableOpacity
                style={styles.registerBtn}
                onPress={() => navigation.navigate('Register')}
              >
                <Ionicons name="person-add-outline" size={16} color={COLORS.navy} style={{ marginRight: 6 }} />
                <Text style={styles.registerBtnText}>Create New Account</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.activateLink}
                onPress={() => navigation.navigate('Activate')}
              >
                <Text style={styles.activateLinkText}>Have an activation code? </Text>
                <Text style={styles.activateLinkBold}>Activate account</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.footer}>
              <Ionicons name="server-outline" size={11} color={COLORS.textMuted} /> FastAPI · localhost:8001
            </Text>
          </ScrollView>
        </KeyboardAvoidingView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  root:       { flex: 1, backgroundColor: COLORS.bg },
  flex:       { flex: 1 },
  topSection: {
    paddingTop: 60, paddingBottom: 50,
    alignItems: 'center', position: 'relative', overflow: 'hidden',
  },
  logoWrap:   { alignItems: 'center', zIndex: 1 },
  logoOuter: {
    width: 88, height: 88, borderRadius: 44,
    backgroundColor: 'rgba(233,166,25,0.15)',
    justifyContent: 'center', alignItems: 'center', marginBottom: 16,
    borderWidth: 1.5, borderColor: 'rgba(233,166,25,0.3)',
  },
  logoInner: {
    width: 68, height: 68, borderRadius: 34,
    backgroundColor: 'rgba(233,166,25,0.12)',
    justifyContent: 'center', alignItems: 'center',
  },
  appName:    { fontSize: 30, fontWeight: '900', color: COLORS.white, letterSpacing: 1 },
  appTagline: { fontSize: 12, color: 'rgba(255,255,255,0.55)', marginTop: 5, letterSpacing: 0.5 },
  dot1: {
    position: 'absolute', width: 160, height: 160, borderRadius: 80,
    backgroundColor: 'rgba(255,255,255,0.03)', top: -40, right: -40,
  },
  dot2: {
    position: 'absolute', width: 100, height: 100, borderRadius: 50,
    backgroundColor: 'rgba(233,166,25,0.06)', bottom: 0, left: 20,
  },
  scroll:     { flexGrow: 1, padding: 20, paddingTop: 0 },
  card: {
    backgroundColor: COLORS.card, borderRadius: RADIUS.xl,
    padding: 28, marginTop: -24, ...SHADOW.lg,
  },
  cardTitle:  { fontSize: FONT.xxl, fontWeight: '900', color: COLORS.text, marginBottom: 4 },
  cardSub:    { fontSize: FONT.sm, color: COLORS.textMuted, marginBottom: 24 },
  loginBtn:   { marginTop: 8 },
  divider:    { flexDirection: 'row', alignItems: 'center', marginVertical: 18, gap: 10 },
  dividerLine:{ flex: 1, height: 1, backgroundColor: COLORS.border },
  dividerText:{ fontSize: FONT.xs, color: COLORS.textMuted, fontWeight: '600' },
  registerBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: COLORS.navy, borderRadius: RADIUS.md,
    paddingVertical: 13,
  },
  registerBtnText: { fontSize: FONT.md, fontWeight: '700', color: COLORS.navy },
  activateLink: {
    flexDirection: 'row', justifyContent: 'center',
    marginTop: 18, alignItems: 'center',
  },
  activateLinkText: { fontSize: FONT.sm, color: COLORS.textMuted },
  activateLinkBold: { fontSize: FONT.sm, color: COLORS.gold, fontWeight: '700' },
  footer: { textAlign: 'center', marginTop: 20, fontSize: FONT.xs, color: COLORS.textMuted },
});
