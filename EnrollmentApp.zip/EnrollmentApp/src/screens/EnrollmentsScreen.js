import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  Alert, TextInput, Modal, ScrollView, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import {
  getEnrollments, createEnrollment, dropEnrollment,
  confirmEnrollment, rejectEnrollment,
  getSections, getStudents,
} from '../services/api';
import { AppButton, EmptyState, LoadingView, Badge } from '../components/UI';
import { COLORS, RADIUS, SHADOW } from '../theme';
import { useAuth } from '../context/AuthContext';

const STATUS_BADGE_COLOR = {
  pending:  '#f59e0b',
  enrolled: COLORS.success,
  rejected: COLORS.danger,
  dropped:  COLORS.textMuted,
};

const STUDENT_STATUS_TABS = [
  { value: 'pending',  label: 'Pending'  },
  { value: 'enrolled', label: 'Enrolled' },
  { value: 'dropped',  label: 'Dropped'  },
];

const ADMIN_STATUS_TABS = [
  { value: 'pending',  label: 'Pending'  },
  { value: 'enrolled', label: 'Enrolled' },
  { value: 'rejected', label: 'Rejected' },
  { value: 'dropped',  label: 'Dropped'  },
];

export default function EnrollmentsScreen({ route }) {
  const { user } = useAuth();

  // ✅ FIX 1: FastAPI returns is_staff/is_superuser — NOT role
  const isAdmin = user?.is_staff === true || user?.is_superuser === true;

  const [enrollments, setEnrollments]     = useState([]);
  const [loading, setLoading]             = useState(true);
  const [search, setSearch]               = useState('');
  const [filterStatus, setFilterStatus]   = useState('pending');
  const [modalVisible, setModal]          = useState(false);
  const [saving, setSaving]               = useState(false);
  const [actionLoading, setActionLoading] = useState(null);
  const [myStudentId, setMyStudentId]     = useState(null);

  // Dropdown state
  const [sections, setSections]           = useState([]);
  const [students, setStudents]           = useState([]);
  const [selectedSection, setSelectedSection] = useState(null);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [remarks, setRemarks]             = useState('');

  // Picker modals
  const [sectionPicker, setSectionPicker] = useState(false);
  const [studentPicker, setStudentPicker] = useState(false);
  const [sectionSearch, setSectionSearch] = useState('');
  const [studentSearch, setStudentSearch] = useState('');

  // ── Resolve student DB id from logged-in user's email ────────────────────
  const resolveStudentId = async () => {
    if (isAdmin) return null;
    if (myStudentId) return myStudentId;

    const email = user?.email;
    if (!email) return null;

    try {
      const res  = await getStudents({ search: email });
      const list = Array.isArray(res.data) ? res.data : (res.data.results ?? []);
      const match = list.find((s) => s.email?.toLowerCase() === email.toLowerCase());
      if (!match) return null;
      setMyStudentId(match.id);
      return match.id;
    } catch (e) {
      console.warn('resolveStudentId error:', e);
      return null;
    }
  };

  // ── Fetch enrollments ─────────────────────────────────────────────────────
  const fetchEnrollments = async (q = '', s = '') => {
    try {
      setLoading(true);
      const params = {};
      if (q) params.search = q;
      if (s) params.status = s;

      if (!isAdmin) {
        const studentId = await resolveStudentId();
        if (studentId) {
          params.student = studentId;
        } else {
          setEnrollments([]);
          return;
        }
      }

      const res = await getEnrollments(params);
      setEnrollments(Array.isArray(res.data) ? res.data : (res.data.results ?? []));
    } catch (e) { console.warn('fetchEnrollments error:', e); }
    finally { setLoading(false); }
  };

  useFocusEffect(useCallback(() => {
    fetchEnrollments(search, filterStatus);
  }, [filterStatus, isAdmin]));

  const handleSearch = (text) => { setSearch(text); fetchEnrollments(text, filterStatus); };

  // ── Fetch dropdowns ───────────────────────────────────────────────────────
  const fetchDropdowns = async () => {
    try {
      // ✅ FIX 2: Always fetch all sections — not filtered by status
      const [secRes, stuRes] = await Promise.all([
        getSections(),
        isAdmin ? getStudents() : Promise.resolve(null),
      ]);

      const secs = Array.isArray(secRes.data) ? secRes.data : (secRes.data.results ?? []);
      setSections(secs);

      if (isAdmin && stuRes) {
        const stus = Array.isArray(stuRes.data) ? stuRes.data : (stuRes.data.results ?? []);
        setStudents(stus);
      }
    } catch (e) {
      console.warn('fetchDropdowns error:', e);
      Alert.alert('Error', 'Could not load sections.');
    }
  };

  const openAdd = async () => {
    setSelectedSection(null);
    setSelectedStudent(null);
    setRemarks('');
    await fetchDropdowns();
    setModal(true);
  };

  const handleSave = async () => {
    if (!selectedSection) return Alert.alert('Validation', 'Please select a section.');
    if (isAdmin && !selectedStudent) return Alert.alert('Validation', 'Please select a student.');
    setSaving(true);
    try {
      const studentId = isAdmin
        ? selectedStudent.id
        : (myStudentId ?? (await resolveStudentId()));

      if (!studentId) {
        Alert.alert('Error', 'Could not find your student record. Make sure your account email matches your student profile.');
        return;
      }

      // ✅ FIX 3: Status is always 'pending' — admin confirms/rejects
      await createEnrollment({
        student: studentId,
        section: selectedSection.id,
        status:  'pending',
        remarks,
      });

      setModal(false);
      Alert.alert('✅ Submitted', 'Your enrollment request has been submitted. Please wait for admin approval.');
      fetchEnrollments(search, filterStatus);
    } catch (e) {
      const err = e.response?.data?.detail || e.response?.data;
      Alert.alert('Error', typeof err === 'string' ? err : (JSON.stringify(err) || 'Could not enroll.'));
    } finally { setSaving(false); }
  };

  const handleDrop = (enr) => {
    Alert.alert('Drop Enrollment', `Drop ${getStudentName(enr)} from ${getSectionName(enr)}?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Drop', style: 'destructive', onPress: async () => {
          try {
            await dropEnrollment(enr.id);
            fetchEnrollments(search, filterStatus);
          } catch (_) { Alert.alert('Error', 'Could not drop enrollment.'); }
        },
      },
    ]);
  };

  const handleConfirm = async (enr) => {
    setActionLoading(enr.id);
    try {
      await confirmEnrollment(enr.id);
      fetchEnrollments(search, filterStatus);
    } catch (e) {
      Alert.alert('Error', e.response?.data?.detail || 'Could not confirm.');
    }
    finally { setActionLoading(null); }
  };

  const handleReject = (enr) => {
    Alert.alert('Reject', 'Reject this enrollment request?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Reject', style: 'destructive', onPress: async () => {
          setActionLoading(enr.id);
          try {
            await rejectEnrollment(enr.id);
            fetchEnrollments(search, filterStatus);
          } catch (e) {
            Alert.alert('Error', e.response?.data?.detail || 'Could not reject.');
          }
          finally { setActionLoading(null); }
        },
      },
    ]);
  };

  // ── Helpers ───────────────────────────────────────────────────────────────
  const getStudentName = (enr) => {
    const d = enr.student_details;
    if (d) return d.full_name || `${d.first_name || ''} ${d.last_name || ''}`.trim();
    return `Student #${enr.student}`;
  };

  const getSectionName = (enr) =>
    enr.section_details?.section_name ?? `Section #${enr.section}`;

  const getSubjectName = (enr) =>
    enr.section_details?.subject_details?.name ?? null;

  // ✅ FIX 4: Show ALL sections in picker, not just non-full ones
  // Student can still try — FastAPI will reject if full
  const filteredSections = sections.filter((s) =>
    `${s.section_name} ${s.subject_details?.subject_code || ''} ${s.subject_details?.name || ''}`
      .toLowerCase().includes(sectionSearch.toLowerCase())
  );

  const filteredStudents = students.filter((s) =>
    `${s.full_name || ''} ${s.student_id || ''}`
      .toLowerCase().includes(studentSearch.toLowerCase())
  );

  const tabs = isAdmin ? ADMIN_STATUS_TABS : STUDENT_STATUS_TABS;

  // ── Render ────────────────────────────────────────────────────────────────
  const renderItem = ({ item: enr }) => (
    <View style={styles.card}>
      <View style={styles.cardRow}>
        <View style={styles.iconBox}>
          <Ionicons name="school" size={20} color="#6a1b9a" />
        </View>
        <View style={styles.cardInfo}>
          <Text style={styles.studentName}>{getStudentName(enr)}</Text>
          <Text style={styles.sectionLabel}>{getSectionName(enr)}</Text>
          {getSubjectName(enr)
            ? <Text style={styles.detail}>{getSubjectName(enr)}</Text>
            : null}
          {enr.remarks ? <Text style={styles.detail}>📝 {enr.remarks}</Text> : null}
          {enr.enrolled_at
            ? <Text style={styles.detail}>
                {new Date(enr.enrolled_at).toLocaleDateString()}
              </Text>
            : null}
        </View>
        <Badge
          label={enr.status}
          color={STATUS_BADGE_COLOR[enr.status] || COLORS.textMuted}
        />
      </View>

      {/* ✅ FIX 5: Admin actions only shown to actual admins */}
      <View style={styles.cardFooter}>
        {isAdmin && enr.status === 'pending' && (
          <>
            <TouchableOpacity
              style={[styles.actionBtn, { backgroundColor: '#e6fff0' }]}
              disabled={actionLoading === enr.id}
              onPress={() => handleConfirm(enr)}
            >
              <Ionicons name="checkmark-circle-outline" size={15} color={COLORS.success} />
              <Text style={[styles.actionText, { color: COLORS.success }]}>
                {actionLoading === enr.id ? ' ...' : ' Confirm'}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionBtn, { backgroundColor: '#ffebee' }]}
              disabled={actionLoading === enr.id}
              onPress={() => handleReject(enr)}
            >
              <Ionicons name="close-circle-outline" size={15} color={COLORS.danger} />
              <Text style={[styles.actionText, { color: COLORS.danger }]}> Reject</Text>
            </TouchableOpacity>
          </>
        )}
        {isAdmin && enr.status === 'enrolled' && (
          <TouchableOpacity style={styles.deleteBtn} onPress={() => handleDrop(enr)}>
            <Ionicons name="remove-circle-outline" size={14} color={COLORS.danger} />
            <Text style={styles.deleteText}>  Drop</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );

  return (
    <View style={styles.container}>

      {/* Top Bar */}
      <View style={styles.topBar}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search enrollments..."
          placeholderTextColor={COLORS.textMuted}
          value={search}
          onChangeText={handleSearch}
        />
        <TouchableOpacity style={styles.addBtn} onPress={openAdd}>
          <Ionicons name="add" size={18} color="#fff" />
          <Text style={styles.addBtnText}> Enroll</Text>
        </TouchableOpacity>
      </View>

      {/* Status Tabs */}
      <View style={styles.tabRow}>
        {tabs.map(tab => (
          <TouchableOpacity
            key={tab.value}
            style={[
              styles.tab,
              filterStatus === tab.value && {
                backgroundColor: COLORS.primary,
                borderColor:     COLORS.primary,
              },
            ]}
            onPress={() => setFilterStatus(tab.value)}
          >
            <Text style={[
              styles.tabText,
              filterStatus === tab.value && { color: '#fff' },
            ]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* List */}
      {loading
        ? <LoadingView />
        : <FlatList
            data={enrollments}
            keyExtractor={(i) => String(i.id)}
            renderItem={renderItem}
            contentContainerStyle={styles.list}
            ListEmptyComponent={
              <EmptyState message="No enrollments found." />
            }
          />
      }

      {/* Enroll Modal */}
      <Modal visible={modalVisible} animationType="slide" onRequestClose={() => setModal(false)}>
        <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setModal(false)}>
              <Ionicons name="close" size={24} color={COLORS.textMuted} />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>New Enrollment</Text>
            <View style={{ width: 32 }} />
          </View>
          <ScrollView contentContainerStyle={styles.modalBody} keyboardShouldPersistTaps="handled">

            <Text style={styles.pickerLabel}>Section *</Text>
            <TouchableOpacity
              style={styles.pickerBtn}
              onPress={() => { setSectionPicker(true); setSectionSearch(''); }}
            >
              <Text style={[styles.pickerBtnText, !selectedSection && { color: COLORS.textMuted }]}>
                {selectedSection
                  ? `${selectedSection.section_name} (${selectedSection.available_slots} slots left)`
                  : 'Select a section...'}
              </Text>
              <Ionicons name="chevron-down" size={16} color={COLORS.textMuted} />
            </TouchableOpacity>

            {isAdmin && (
              <>
                <Text style={[styles.pickerLabel, { marginTop: 14 }]}>Student *</Text>
                <TouchableOpacity
                  style={styles.pickerBtn}
                  onPress={() => { setStudentPicker(true); setStudentSearch(''); }}
                >
                  <Text style={[styles.pickerBtnText, !selectedStudent && { color: COLORS.textMuted }]}>
                    {selectedStudent
                      ? `${selectedStudent.full_name} (${selectedStudent.student_id})`
                      : 'Select student...'}
                  </Text>
                  <Ionicons name="chevron-down" size={16} color={COLORS.textMuted} />
                </TouchableOpacity>
              </>
            )}

            <Text style={[styles.pickerLabel, { marginTop: 14 }]}>Remarks (optional)</Text>
            <TextInput
              style={styles.remarksInput}
              value={remarks}
              onChangeText={setRemarks}
              placeholder="Any notes..."
              placeholderTextColor={COLORS.textMuted}
              multiline
            />

            <AppButton
              title={isAdmin ? 'Enroll Student' : 'Submit Request'}
              onPress={handleSave}
              loading={saving}
              style={{ marginTop: 16 }}
            />
            <AppButton
              title="Cancel"
              onPress={() => setModal(false)}
              variant="outline"
              style={{ marginTop: 10 }}
            />
          </ScrollView>
        </KeyboardAvoidingView>
      </Modal>

      {/* Section Picker */}
      <Modal visible={sectionPicker} animationType="slide" onRequestClose={() => setSectionPicker(false)}>
        <View style={styles.flex}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setSectionPicker(false)}>
              <Ionicons name="close" size={24} color={COLORS.textMuted} />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Select Section</Text>
            <View style={{ width: 32 }} />
          </View>
          <View style={{ padding: 16 }}>
            <TextInput
              style={styles.searchInput}
              placeholder="Search sections..."
              placeholderTextColor={COLORS.textMuted}
              value={sectionSearch}
              onChangeText={setSectionSearch}
              autoFocus
            />
          </View>
          <FlatList
            data={filteredSections}
            keyExtractor={(i) => String(i.id)}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={[styles.pickerItem, item.is_full && { opacity: 0.5 }]}
                onPress={() => {
                  if (item.is_full) {
                    Alert.alert('Section Full', `${item.section_name} has no available slots.`);
                    return;
                  }
                  setSelectedSection(item);
                  setSectionPicker(false);
                }}
              >
                <Text style={styles.pickerCode}>{item.section_name}</Text>
                {item.subject_details
                  ? <Text style={styles.pickerName}>
                      {item.subject_details.subject_code} — {item.subject_details.name}
                    </Text>
                  : null}
                <Text style={[styles.pickerMeta, item.is_full && { color: COLORS.danger }]}>
                  {item.is_full
                    ? '❌ Full'
                    : `${item.available_slots} slot${item.available_slots !== 1 ? 's' : ''} available`}
                  {item.schedule ? ` · ${item.schedule}` : ''}
                  {item.room     ? ` · ${item.room}`     : ''}
                </Text>
              </TouchableOpacity>
            )}
            contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 40 }}
            ListEmptyComponent={<EmptyState message="No sections found." />}
          />
        </View>
      </Modal>

      {/* Student Picker (admin only) */}
      <Modal visible={studentPicker} animationType="slide" onRequestClose={() => setStudentPicker(false)}>
        <View style={styles.flex}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setStudentPicker(false)}>
              <Ionicons name="close" size={24} color={COLORS.textMuted} />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Select Student</Text>
            <View style={{ width: 32 }} />
          </View>
          <View style={{ padding: 16 }}>
            <TextInput
              style={styles.searchInput}
              placeholder="Search by name or ID..."
              placeholderTextColor={COLORS.textMuted}
              value={studentSearch}
              onChangeText={setStudentSearch}
              autoFocus
            />
          </View>
          <FlatList
            data={filteredStudents}
            keyExtractor={(i) => String(i.id)}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={styles.pickerItem}
                onPress={() => { setSelectedStudent(item); setStudentPicker(false); }}
              >
                <Text style={styles.pickerCode}>{item.full_name}</Text>
                <Text style={styles.pickerMeta}>
                  {item.student_id} · {item.course || 'No course'} · Year {item.year_level}
                </Text>
              </TouchableOpacity>
            )}
            contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 40 }}
            ListEmptyComponent={<EmptyState message="No students found." />}
          />
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  flex:      { flex: 1, backgroundColor: '#fff' },
  container: { flex: 1, backgroundColor: COLORS.bg },
  topBar: {
    flexDirection: 'row', padding: 16, gap: 10,
    backgroundColor: COLORS.card, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  searchInput: {
    flex: 1, backgroundColor: COLORS.bg, borderRadius: RADIUS.sm,
    paddingHorizontal: 14, paddingVertical: 9, fontSize: 14,
    color: COLORS.text, borderWidth: 1, borderColor: COLORS.border,
  },
  addBtn: {
    backgroundColor: COLORS.primary, borderRadius: RADIUS.sm,
    paddingHorizontal: 16, justifyContent: 'center',
    flexDirection: 'row', alignItems: 'center',
  },
  addBtnText:   { color: '#fff', fontWeight: '700', fontSize: 14 },
  tabRow: {
    flexDirection: 'row', padding: 10, gap: 6,
    backgroundColor: COLORS.card, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  tab: {
    flex: 1, paddingVertical: 8, alignItems: 'center',
    borderRadius: 20, borderWidth: 1.5, borderColor: COLORS.border,
  },
  tabText:      { fontSize: 11, fontWeight: '600', color: COLORS.textMuted },
  list:         { padding: 16 },
  card: {
    backgroundColor: COLORS.card, borderRadius: RADIUS.md,
    padding: 14, marginBottom: 12, ...SHADOW.light,
  },
  cardRow:      { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 6 },
  iconBox: {
    width: 42, height: 42, borderRadius: 21,
    backgroundColor: '#ede7f6', justifyContent: 'center',
    alignItems: 'center', marginRight: 12,
  },
  cardInfo:     { flex: 1 },
  studentName:  { fontSize: 15, fontWeight: '700', color: COLORS.text },
  sectionLabel: { fontSize: 12, color: '#6a1b9a', fontWeight: '600', marginTop: 2 },
  detail:       { fontSize: 12, color: COLORS.textMuted, marginTop: 1 },
  cardFooter:   { flexDirection: 'row', gap: 8, marginTop: 8 },
  actionBtn: {
    flex: 1, borderRadius: RADIUS.sm, padding: 8,
    alignItems: 'center', flexDirection: 'row', justifyContent: 'center',
  },
  actionText:   { fontSize: 13, fontWeight: '600' },
  deleteBtn: {
    flex: 1, backgroundColor: '#ffebee', borderRadius: RADIUS.sm,
    padding: 8, alignItems: 'center', flexDirection: 'row', justifyContent: 'center',
  },
  deleteText:   { fontSize: 13, color: COLORS.danger, fontWeight: '600' },
  modalHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 20, borderBottomWidth: 1, borderBottomColor: COLORS.border, backgroundColor: '#fff',
  },
  modalTitle:   { fontSize: 18, fontWeight: '800', color: COLORS.text },
  modalBody:    { padding: 20, paddingBottom: 40 },
  pickerLabel:  { fontSize: 13, fontWeight: '600', color: COLORS.text, marginBottom: 6 },
  pickerBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: COLORS.white, borderWidth: 1.5, borderColor: COLORS.border,
    borderRadius: RADIUS.sm, paddingHorizontal: 14, paddingVertical: 12,
  },
  pickerBtnText: { fontSize: 15, color: COLORS.text, flex: 1 },
  pickerItem: {
    paddingVertical: 14, paddingHorizontal: 4,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  pickerCode:   { fontSize: 14, fontWeight: '800', color: '#6a1b9a' },
  pickerName:   { fontSize: 14, color: COLORS.text, marginTop: 1 },
  pickerMeta:   { fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  remarksInput: {
    borderWidth: 1.5, borderColor: COLORS.border, borderRadius: RADIUS.sm,
    paddingHorizontal: 14, paddingVertical: 10, fontSize: 14, color: COLORS.text,
    minHeight: 80, textAlignVertical: 'top',
  },
});
