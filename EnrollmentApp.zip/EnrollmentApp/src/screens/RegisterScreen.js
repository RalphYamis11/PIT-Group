import React, { useState } from 'react';
import {
  View, Text, StyleSheet, KeyboardAvoidingView,
  Platform, ScrollView, Alert, TouchableOpacity, StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import axios from 'axios';
import { BASE_URL } from '../services/api';
import { AppInput, AppButton } from '../components/UI';
import { COLORS, FONT, RADIUS, SHADOW } from '../theme';

export default function RegisterScreen({ navigation }) {
  const [form, setForm] = useState({
    email: '', password: '', confirm_password: '',
    first_name: '', last_name: '', address: '', age: '',
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors]   = useState({});
  const [showPass, setShowPass]    = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const f = (k) => (v) => setForm((p) => ({ ...p, [k]: v }));

  const validate = () => {
    const e = {};
    if (!form.first_name.trim())  e.first_name = 'First name is required';
    if (!form.last_name.trim())   e.last_name  = 'Last name is required';
    if (!form.email.trim())       e.email      = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = 'Enter a valid email';
    if (!form.password)           e.password   = 'Password is required';
    else if (form.password.length < 6) e.password = 'At least 6 characters';
    if (form.password !== form.confirm_password) e.confirm_password = 'Passwords do not match';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleRegister = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      await axios.post(`${BASE_URL}/auth/register`, {
        email:      form.email.trim().toLowerCase(),
        password:   form.password,
        first_name: form.first_name.trim(),
        last_name:  form.last_name.trim(),
        address:    form.address.trim(),
        age:        form.age ? parseInt(form.age) : null,
      });
      Alert.alert(
        'Account Created!',
        'Check your email for the activation link, or check the FastAPI terminal for the activation code.',
        [{ text: 'Activate Now', onPress: () => navigation.navigate('Activate') }]
      );
    } catch (err) {
      const msg = err.response?.data?.detail || 'Registration failed.';
      Alert.alert('Registration Failed', msg);
    } finally { setLoading(false); }
  };

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.navy} />
      <View style={styles.root}>
        <LinearGradient colors={[COLORS.navy, COLORS.navyMid]} style={styles.topBar}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={22} color={COLORS.white} />
          </TouchableOpacity>
          <Text style={styles.topTitle}>Create Account</Text>
          <View style={{ width: 40 }} />
        </LinearGradient>

        <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>

            {/* Info Banner */}
            <View style={styles.infoBanner}>
              <Ionicons name="information-circle-outline" size={18} color={COLORS.info} />
              <Text style={styles.infoText}>
                After registering, you'll receive an activation email. Check your inbox or the FastAPI terminal.
              </Text>
            </View>

            {/* Name Row */}
            <View style={styles.row}>
              <View style={styles.halfInput}>
                <AppInput label="First Name *" value={form.first_name}
                  onChangeText={f('first_name')} error={errors.first_name}
                  placeholder="Juan" icon="person-outline" />
              </View>
              <View style={styles.halfInput}>
                <AppInput label="Last Name *" value={form.last_name}
                  onChangeText={f('last_name')} error={errors.last_name}
                  placeholder="Dela Cruz" icon="person-outline" />
              </View>
            </View>

            <AppInput label="Email Address *" value={form.email}
              onChangeText={f('email')} error={errors.email}
              keyboardType="email-address" autoCapitalize="none"
              placeholder="you@ustp.edu.ph" icon="mail-outline" />

            <AppInput label="Password *" value={form.password}
              onChangeText={f('password')} error={errors.password}
              secureTextEntry={!showPass} placeholder="At least 6 characters"
              icon="lock-closed-outline"
              rightIcon={showPass ? 'eye-off-outline' : 'eye-outline'}
              onRightIconPress={() => setShowPass(!showPass)} />

            <AppInput label="Confirm Password *" value={form.confirm_password}
              onChangeText={f('confirm_password')} error={errors.confirm_password}
              secureTextEntry={!showConfirm} placeholder="Repeat your password"
              icon="lock-closed-outline"
              rightIcon={showConfirm ? 'eye-off-outline' : 'eye-outline'}
              onRightIconPress={() => setShowConfirm(!showConfirm)} />

            <AppInput label="Address" value={form.address}
              onChangeText={f('address')} placeholder="City, Province (optional)"
              icon="location-outline" />

            <AppInput label="Age" value={form.age}
              onChangeText={f('age')} keyboardType="numeric"
              placeholder="Optional" icon="calendar-outline" />

            <AppButton title="Create Account" onPress={handleRegister}
              loading={loading} variant="gold" icon="checkmark-circle-outline"
              style={{ marginTop: 8 }} />

            <TouchableOpacity style={styles.loginLink} onPress={() => navigation.navigate('Login')}>
              <Text style={styles.loginLinkText}>Already have an account? </Text>
              <Text style={styles.loginLinkBold}>Sign in</Text>
            </TouchableOpacity>
          </ScrollView>
        </KeyboardAvoidingView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  root:    { flex: 1, backgroundColor: COLORS.bg },
  flex:    { flex: 1 },
  topBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingTop: Platform.OS === 'ios' ? 54 : 40, paddingBottom: 16,
    paddingHorizontal: 20,
  },
  backBtn:   { width: 40, height: 40, justifyContent: 'center' },
  topTitle:  { fontSize: FONT.lg, fontWeight: '800', color: COLORS.white },
  scroll:    { padding: 20 },
  infoBanner: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 10,
    backgroundColor: COLORS.infoBg, borderRadius: RADIUS.sm,
    padding: 14, marginBottom: 20, borderLeftWidth: 3, borderLeftColor: COLORS.info,
  },
  infoText:  { flex: 1, fontSize: FONT.sm, color: COLORS.info, lineHeight: 20 },
  row:       { flexDirection: 'row', gap: 12 },
  halfInput: { flex: 1 },
  loginLink: { flexDirection: 'row', justifyContent: 'center', marginTop: 20, paddingBottom: 20 },
  loginLinkText: { fontSize: FONT.sm, color: COLORS.textMuted },
  loginLinkBold: { fontSize: FONT.sm, color: COLORS.gold, fontWeight: '700' },
});
