import React from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  ActivityIndicator, StyleSheet, Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, FONT, RADIUS, SHADOW } from '../theme';

// ─── Button ──────────────────────────────────────────────────────────────────
export function AppButton({ title, onPress, loading, variant = 'primary', style, disabled, icon }) {
  const isOutline  = variant === 'outline';
  const isDanger   = variant === 'danger';
  const isGold     = variant === 'gold';
  const isGhost    = variant === 'ghost';

  const bg = isDanger ? COLORS.danger
    : isGold    ? COLORS.gold
    : isOutline || isGhost ? 'transparent'
    : COLORS.navy;

  const textColor = isOutline ? COLORS.navy
    : isGhost   ? COLORS.textSub
    : COLORS.white;

  const borderColor = isOutline ? COLORS.navy
    : isDanger  ? COLORS.danger
    : 'transparent';

  const shadow = isGold ? SHADOW.gold : isOutline || isGhost ? {} : SHADOW.md;

  return (
    <TouchableOpacity
      style={[
        styles.btn,
        { backgroundColor: bg, borderColor, borderWidth: isOutline || isDanger ? 1.5 : 0 },
        shadow,
        style,
      ]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}
    >
      {loading ? (
        <ActivityIndicator color={textColor} size="small" />
      ) : (
        <View style={styles.btnInner}>
          {icon && <Ionicons name={icon} size={17} color={textColor} style={{ marginRight: 6 }} />}
          <Text style={[styles.btnText, { color: textColor }]}>{title}</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

// ─── Input ───────────────────────────────────────────────────────────────────
export function AppInput({ label, error, style, icon, rightIcon, onRightIconPress, ...props }) {
  return (
    <View style={[styles.inputWrapper, style]}>
      {label ? <Text style={styles.label}>{label}</Text> : null}
      <View style={[styles.inputRow, error && { borderColor: COLORS.danger }]}>
        {icon && (
          <Ionicons name={icon} size={18} color={error ? COLORS.danger : COLORS.textMuted}
            style={styles.inputIcon} />
        )}
        <TextInput
          style={[styles.input, icon && { paddingLeft: 0 }]}
          placeholderTextColor={COLORS.textMuted}
          {...props}
        />
        {rightIcon && (
          <TouchableOpacity onPress={onRightIconPress} style={styles.rightIcon}>
            <Ionicons name={rightIcon} size={18} color={COLORS.textMuted} />
          </TouchableOpacity>
        )}
      </View>
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
    </View>
  );
}

// ─── Card ────────────────────────────────────────────────────────────────────
export function Card({ children, style, onPress }) {
  if (onPress) {
    return (
      <TouchableOpacity style={[styles.card, style]} onPress={onPress} activeOpacity={0.85}>
        {children}
      </TouchableOpacity>
    );
  }
  return <View style={[styles.card, style]}>{children}</View>;
}

// ─── Screen Header ───────────────────────────────────────────────────────────
export function ScreenHeader({ title, subtitle, icon, right }) {
  return (
    <View style={styles.screenHeader}>
      <View style={styles.screenHeaderLeft}>
        {icon && (
          <View style={styles.headerIconBox}>
            <Ionicons name={icon} size={20} color={COLORS.gold} />
          </View>
        )}
        <View>
          <Text style={styles.screenHeaderTitle}>{title}</Text>
          {subtitle ? <Text style={styles.screenHeaderSub}>{subtitle}</Text> : null}
        </View>
      </View>
      {right}
    </View>
  );
}

// ─── Search Bar ──────────────────────────────────────────────────────────────
export function SearchBar({ value, onChangeText, placeholder, onAdd, addLabel = 'Add' }) {
  return (
    <View style={styles.searchBar}>
      <View style={styles.searchInput}>
        <Ionicons name="search-outline" size={16} color={COLORS.textMuted} style={{ marginRight: 8 }} />
        <TextInput
          style={styles.searchText}
          placeholder={placeholder || 'Search...'}
          placeholderTextColor={COLORS.textMuted}
          value={value}
          onChangeText={onChangeText}
        />
        {value ? (
          <TouchableOpacity onPress={() => onChangeText('')}>
            <Ionicons name="close-circle" size={16} color={COLORS.textMuted} />
          </TouchableOpacity>
        ) : null}
      </View>
      {onAdd && (
        <TouchableOpacity style={styles.addBtn} onPress={onAdd}>
          <Ionicons name="add" size={18} color={COLORS.white} />
          <Text style={styles.addBtnText}>{addLabel}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

// ─── Badge ───────────────────────────────────────────────────────────────────
export function Badge({ label, color = COLORS.navy, bg }) {
  const bgColor = bg || color + '18';
  return (
    <View style={[styles.badge, { backgroundColor: bgColor }]}>
      <Text style={[styles.badgeText, { color }]}>{label}</Text>
    </View>
  );
}

// ─── Stat Card ───────────────────────────────────────────────────────────────
export function StatCard({ label, value, icon, color = COLORS.navy, onPress }) {
  return (
    <TouchableOpacity style={[styles.statCard, { borderTopColor: color }]}
      onPress={onPress} activeOpacity={0.85}>
      <View style={[styles.statIconBox, { backgroundColor: color + '14' }]}>
        <Ionicons name={icon} size={20} color={color} />
      </View>
      <Text style={[styles.statValue, { color }]}>{value ?? '—'}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

// ─── Empty State ─────────────────────────────────────────────────────────────
export function EmptyState({ message = 'No records found.', icon = 'file-tray-outline' }) {
  return (
    <View style={styles.emptyState}>
      <View style={styles.emptyIconBox}>
        <Ionicons name={icon} size={36} color={COLORS.textMuted} />
      </View>
      <Text style={styles.emptyText}>{message}</Text>
    </View>
  );
}

// ─── Loading ─────────────────────────────────────────────────────────────────
export function LoadingView() {
  return (
    <View style={styles.loadingView}>
      <ActivityIndicator size="large" color={COLORS.gold} />
    </View>
  );
}

// ─── Section Label ───────────────────────────────────────────────────────────
export function SectionLabel({ title, action, actionLabel }) {
  return (
    <View style={styles.sectionLabelRow}>
      <Text style={styles.sectionLabelText}>{title}</Text>
      {action && (
        <TouchableOpacity onPress={action}>
          <Text style={styles.sectionAction}>{actionLabel || 'See all'}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

// ─── Modal Header ────────────────────────────────────────────────────────────
export function ModalHeader({ title, onClose }) {
  return (
    <View style={styles.modalHeader}>
      <Text style={styles.modalTitle}>{title}</Text>
      <TouchableOpacity onPress={onClose} style={styles.modalCloseBtn}>
        <Ionicons name="close" size={22} color={COLORS.textSub} />
      </TouchableOpacity>
    </View>
  );
}

// ─── Avatar ──────────────────────────────────────────────────────────────────
export function Avatar({ name, size = 44, color = COLORS.navy }) {
  const initials = name
    ? name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()
    : '?';
  return (
    <View style={[styles.avatar, { width: size, height: size, borderRadius: size / 2, backgroundColor: color + '20' }]}>
      <Text style={[styles.avatarText, { color, fontSize: size * 0.38 }]}>{initials}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  // Button
  btn: {
    borderRadius: RADIUS.md, paddingVertical: 14,
    paddingHorizontal: 24, alignItems: 'center', justifyContent: 'center',
  },
  btnInner: { flexDirection: 'row', alignItems: 'center' },
  btnText: { fontSize: FONT.md, fontWeight: '700', letterSpacing: 0.3 },

  // Input
  inputWrapper: { marginBottom: 14 },
  label: {
    fontSize: FONT.sm, fontWeight: '600', color: COLORS.textSub,
    marginBottom: 6, letterSpacing: 0.2,
  },
  inputRow: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: COLORS.card, borderWidth: 1.5,
    borderColor: COLORS.border, borderRadius: RADIUS.sm,
    paddingHorizontal: 14,
  },
  inputIcon: { marginRight: 10 },
  input: {
    flex: 1, paddingVertical: Platform.OS === 'ios' ? 13 : 10,
    fontSize: FONT.md, color: COLORS.text,
  },
  rightIcon: { padding: 4 },
  errorText: { color: COLORS.danger, fontSize: FONT.xs, marginTop: 4 },

  // Card
  card: {
    backgroundColor: COLORS.card, borderRadius: RADIUS.md,
    padding: 16, marginBottom: 12, ...SHADOW.sm,
  },

  // Screen Header
  screenHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingVertical: 16,
    backgroundColor: COLORS.card, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  screenHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  headerIconBox: {
    width: 40, height: 40, borderRadius: RADIUS.sm,
    backgroundColor: COLORS.goldBg, justifyContent: 'center', alignItems: 'center',
  },
  screenHeaderTitle: { fontSize: FONT.lg, fontWeight: '800', color: COLORS.text },
  screenHeaderSub: { fontSize: FONT.xs, color: COLORS.textMuted, marginTop: 1 },

  // Search Bar
  searchBar: {
    flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 12,
    backgroundColor: COLORS.card, borderBottomWidth: 1,
    borderBottomColor: COLORS.border, gap: 10,
  },
  searchInput: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    backgroundColor: COLORS.bg, borderRadius: RADIUS.sm,
    paddingHorizontal: 12, paddingVertical: 9,
    borderWidth: 1, borderColor: COLORS.border,
  },
  searchText: { flex: 1, fontSize: FONT.sm, color: COLORS.text },
  addBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: COLORS.navy, borderRadius: RADIUS.sm,
    paddingHorizontal: 14, paddingVertical: 9,
  },
  addBtnText: { color: COLORS.white, fontWeight: '700', fontSize: FONT.sm },

  // Badge
  badge: {
    borderRadius: RADIUS.full, paddingHorizontal: 10,
    paddingVertical: 3, alignSelf: 'flex-start',
  },
  badgeText: { fontSize: FONT.xs, fontWeight: '700', letterSpacing: 0.3 },

  // Stat Card
  statCard: {
    backgroundColor: COLORS.card, borderRadius: RADIUS.md,
    padding: 16, width: '47%', borderTopWidth: 3, ...SHADOW.sm,
  },
  statIconBox: {
    width: 38, height: 38, borderRadius: RADIUS.sm,
    justifyContent: 'center', alignItems: 'center', marginBottom: 10,
  },
  statValue: { fontSize: FONT.xxl, fontWeight: '900', marginBottom: 2 },
  statLabel: { fontSize: FONT.xs, color: COLORS.textMuted, fontWeight: '600' },

  // Empty State
  emptyState: { alignItems: 'center', paddingVertical: 50 },
  emptyIconBox: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: COLORS.bgDeep, justifyContent: 'center',
    alignItems: 'center', marginBottom: 14,
  },
  emptyText: { color: COLORS.textMuted, fontSize: FONT.md, fontWeight: '500' },

  // Loading
  loadingView: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: COLORS.bg },

  // Section Label
  sectionLabelRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', marginBottom: 10, marginTop: 4,
    paddingHorizontal: 20,
  },
  sectionLabelText: { fontSize: FONT.md, fontWeight: '700', color: COLORS.text },
  sectionAction: { fontSize: FONT.sm, color: COLORS.gold, fontWeight: '700' },

  // Modal Header
  modalHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 24, paddingVertical: 18,
    borderBottomWidth: 1, borderBottomColor: COLORS.border, backgroundColor: COLORS.card,
  },
  modalTitle: { fontSize: FONT.lg, fontWeight: '800', color: COLORS.text },
  modalCloseBtn: {
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: COLORS.bg, justifyContent: 'center', alignItems: 'center',
  },

  // Avatar
  avatar: { justifyContent: 'center', alignItems: 'center' },
  avatarText: { fontWeight: '800' },
});
