// ─── EnrollPro Design System ──────────────────────────────────────────────────
// Deep Blue + Gold  |  Modern FinTech/EdTech aesthetic

export const COLORS = {
  // Primary palette
  navy:        '#0B1D51',
  navyLight:   '#1A3272',
  navyMid:     '#132860',
  blue:        '#1E40AF',

  // Gold accent
  gold:        '#E9A619',
  goldLight:   '#F5BC42',
  goldDark:    '#C48A10',
  goldBg:      '#FEF3DC',

  // Backgrounds
  bg:          '#EEF2FF',
  bgDeep:      '#E4EAFF',
  card:        '#FFFFFF',

  // Text
  text:        '#0B1D51',
  textSub:     '#3D4F7C',
  textMuted:   '#7B8BB2',
  white:       '#FFFFFF',

  // Status
  success:     '#059669',
  successBg:   '#D1FAE5',
  danger:      '#DC2626',
  dangerBg:    '#FEE2E2',
  warning:     '#D97706',
  warningBg:   '#FEF3C7',
  info:        '#2563EB',
  infoBg:      '#DBEAFE',

  // UI
  border:      '#D8E0F5',
  borderLight: '#EEF2FF',
  shadow:      '#0B1D51',
};

export const FONT = {
  xs:   11,
  sm:   13,
  md:   15,
  lg:   17,
  xl:   20,
  xxl:  24,
  xxxl: 32,
};

export const RADIUS = {
  xs:  6,
  sm:  10,
  md:  14,
  lg:  20,
  xl:  26,
  full: 999,
};

export const SHADOW = {
  sm: {
    shadowColor: '#0B1D51',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.07,
    shadowRadius: 8,
    elevation: 2,
  },
  md: {
    shadowColor: '#0B1D51',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 14,
    elevation: 5,
  },
  lg: {
    shadowColor: '#0B1D51',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.14,
    shadowRadius: 24,
    elevation: 10,
  },
  gold: {
    shadowColor: '#E9A619',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 6,
  },
};
