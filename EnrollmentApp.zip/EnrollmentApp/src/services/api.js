import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

// ─── BASE URL ─────────────────────────────────────────────────────────────────
// Web browser testing  → http://localhost:8001
// Real device on WiFi  → http://10.0.0.41:8001  (your PC's local IP)
export const BASE_URL = 'http://10.0.0.41:8001';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT Bearer token
api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('auth_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// ─── AUTH ─────────────────────────────────────────────────────────────────────
export const login      = (email, password) => api.post('/auth/login', { email, password });
export const getProfile = ()                => api.get('/auth/profile');
export const register   = (data)            => api.post('/auth/register', data);
export const activate   = (uid, token)      => api.post('/auth/activate', { uid, token });

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
export const getDashboard = () => api.get('/dashboard');

// ─── STUDENTS ─────────────────────────────────────────────────────────────────
export const getStudents   = (params = {}) => api.get('/students/', { params });
export const getStudent    = (id)          => api.get(`/students/${id}`);
export const createStudent = (data)        => api.post('/students/', data);
export const updateStudent = (id, data)    => api.put(`/students/${id}`, data);
export const deleteStudent = (id)          => api.delete(`/students/${id}`);

// ─── SUBJECTS ─────────────────────────────────────────────────────────────────
export const getSubjects   = (params = {}) => api.get('/subjects/', { params });
export const getSubject    = (id)          => api.get(`/subjects/${id}`);
export const createSubject = (data)        => api.post('/subjects/', data);
export const updateSubject = (id, data)    => api.put(`/subjects/${id}`, data);
export const deleteSubject = (id)          => api.delete(`/subjects/${id}`);

// ─── SECTIONS ─────────────────────────────────────────────────────────────────
export const getSections   = (params = {}) => api.get('/sections/', { params });
export const getSection    = (id)          => api.get(`/sections/${id}`);
export const createSection = (data)        => api.post('/sections/', data);
export const updateSection = (id, data)    => api.put(`/sections/${id}`, data);
export const deleteSection = (id)          => api.delete(`/sections/${id}`);

// ─── ENROLLMENTS ──────────────────────────────────────────────────────────────
// Student submits → status='pending' → Admin confirms → status='enrolled'
// DELETE sets status='dropped' (soft delete)
export const getEnrollments    = (params = {}) => api.get('/enrollments/', { params });
export const getEnrollment     = (id)          => api.get(`/enrollments/${id}`);
export const createEnrollment  = (data)        => api.post('/enrollments/', data);
export const updateEnrollment  = (id, data)    => api.put(`/enrollments/${id}`, data);
export const dropEnrollment    = (id)          => api.delete(`/enrollments/${id}`);
export const confirmEnrollment = (id)          => api.post(`/enrollments/${id}/confirm`);
export const rejectEnrollment  = (id)          => api.post(`/enrollments/${id}/reject`);

// ─── SUMMARIES ────────────────────────────────────────────────────────────────
export const getSummaries      = (params = {}) => api.get('/summaries/', { params });
export const getStudentSummary = (id)          => api.get(`/summaries/${id}`);

export default api;
